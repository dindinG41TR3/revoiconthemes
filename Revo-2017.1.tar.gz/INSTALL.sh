#!/bin/bash
sudo cp Revo /usr/share/icons/
echo '===================================='
echo ' OK DONE INSTALL SUKSES '
echo '===================================='
